-- MySQL dump 10.13  Distrib 5.7.44, for Linux (x86_64)
--
-- Host: localhost    Database: share
-- ------------------------------------------------------
-- Server version	5.7.44-log

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `categories`
--

DROP TABLE IF EXISTS `categories`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `categories` (
  `category_id` int(11) NOT NULL AUTO_INCREMENT,
  `category_name` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  PRIMARY KEY (`category_id`)
) ENGINE=MyISAM AUTO_INCREMENT=5 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `categories`
--

LOCK TABLES `categories` WRITE;
/*!40000 ALTER TABLE `categories` DISABLE KEYS */;
INSERT INTO `categories` VALUES (1,'电视剧'),(2,'电影'),(3,'综艺'),(4,'动漫');
/*!40000 ALTER TABLE `categories` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `data`
--

DROP TABLE IF EXISTS `data`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `data` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `title` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `star` varchar(50) COLLATE utf8_unicode_ci NOT NULL,
  `update_time` datetime NOT NULL,
  `introduction` varchar(512) COLLATE utf8_unicode_ci NOT NULL,
  `logo` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `download_url` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `category_id` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `fk_data_category` (`category_id`)
) ENGINE=MyISAM AUTO_INCREMENT=61 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `data`
--

LOCK TABLES `data` WRITE;
/*!40000 ALTER TABLE `data` DISABLE KEYS */;
INSERT INTO `data` VALUES (1,'榜上佳婿','王子奇 / 卢昱晓 / 王弘毅 / 孔雪儿 / 鹤秋 / 杨仕泽','2025-05-03 14:58:58','江宁简府千金简明舒意外落崖失忆，却因此躲过灭门惨案，并获心上人陆徜救助，两人相伴共赴京城考学。一直对身份存疑的她进入内宅探案解谜，意外获得身世线索。然而简明舒的调查逐渐陷入困局，她以为自己正独步涉险，但其实背后有陆徜的默默 守护。陆徜的温柔与陪伴进一步融化明舒的心，两人数次历经险阻，携手对抗风雨，最终确认心意，共度余生。','https://vip.123pan.cn/1814266124/ymjew503t0l000d7w32x7kit35q1e0bkDIYPAdizAqevAcxPBIrPAO==.png','https://pan.baidu.com/s/1utIknkOnCBcchgNf90E84A?pwd=1024 ',1),(2,'种地吧 第三季',' 陈少熙 / 何浩楠 / 李昊 / 鹭卓 / 王一珩','2025-05-03 15:00:16','　《种地吧》第三季继续不忘初心，扎根土地！春生夏长，秋收冬藏，四季轮回之间，生命的篇章一直在延续。十个勤天要在后陡门继续精耕细作，也想去探索更广阔的农业天地，去耕耘新的土地，去认识新的朋友，去往每一个需要十个勤天的地方!','https://vip.123pan.cn/1814266124/yk6baz03t0n000d7w33gzqzop4ls1vd5DIYPAdizAqevAcxPBIrPAO==.png','https://pan.baidu.com/s/1HkypPs1dan55wtfhV1C7ow?pwd=1024 ',3),(3,'悬镜',' 任达华 / 朱雨辰 / 张龄心 / 黄羿 / 刘金山','2025-04-29 21:40:24','一起下水道的凶案，让刑警队长徐骁和老刑警林国强碰到一起，两人探案手法风格迥异，但因为对真相和正义的共同追求，逐渐弥合了观点上的分歧，结成亦师亦友的老少搭档。在破案的过程中并不顺利，在考古学者陈楠的帮助下，他们发现作案的凶手有着某种邪恶的思想，凶手难觅、迷雾难驱，他们虽分歧不断，但仍朝着一致的目标倾力探寻。最终使凶手伏法。','https://pic1.imgdb.cn/item/6810d6bc58cb8da5c8d46d72.png','https://pan.baidu.com/s/1cQbrsU9Rl3c1YJnRxpWIBw?pwd=6666 ',1),(4,'成家','秦岚 / 艾伦 / 夏之光 / 卜冠今 / 赵子琪','2025-05-01 20:44:59','“一生要强” 的秦天越（秦岚 饰）被派遣至婚恋网站“牵手网”新收购的子公司思缔妮任职经理。理工科毕业的她热衷于用大数据帮助客户筛选和寻找最匹配的另一半，追求电光石火般的速配。','https://vip.123pan.cn/1814266124/yk6baz03t0l000d7w33fd327txqg3v0mDIYPAdizAqevAcxPBIrPAO==.png','https://pan.baidu.com/s/11wCAOnGDIQLbqEtSJ7vlqQ?pwd=1024 ',1),(5,'我的后半生',' 张国立 / 佟大为 / 梅婷 / 许娣 / 周野芒','2025-04-29 21:42:55','沈卓然是已退休的文学系教授，儿女双全、三代同堂，发妻去世后他在老友的鼓励下开启了相亲之旅。他先后遇到了四位相亲对象。善解人意的护士长因房产与他分道扬镳；女科学家癌症复发选择了不告而别；工会主任的强势让他受到心理打压；酷似发妻的对象提出了让他为难的要求。','https://pic1.imgdb.cn/item/6810d75458cb8da5c8d46dca.png','https://pan.baidu.com/s/1CFS5syGtCow5gZjL_056KQ?pwd=6666 ',1),(6,'侠客行不通',' 徐志胜 / 范静祎 / 王帅 / 骆诗琪 / 初俊辰','2025-04-29 21:45:24','天生凶相却心地善良的苟凌风（徐志胜 饰）怀揣一个大侠梦，阴差阳错地误学了一身魔教武功踏入江湖，在世人的偏见与刁难之中，朝着自己的梦想艰难前行。路遇毒仙谷“百花侠”马缨丹（范静祎 饰）、剑圣之子诸葛恒（王帅 饰），与二人并肩闯荡江湖，侦破种种离奇案件，苟凌风逐渐明白“侠无大小，武无正邪”的真理，最终成为真正的大侠。','https://pic1.imgdb.cn/item/6810d7ea58cb8da5c8d46e23.png','https://pan.baidu.com/s/1laGK1pU29ZotU192O7H74w?pwd=6666 ',1),(7,'值得爱',' 王安宇 / 王玉雯 / 黄子琪 / 赵佳丽 / 张帆','2025-04-29 21:47:33','该剧讲述一对八零后的男女在北京平凡而又史诗般的爱情旅程。当最有才华的男生周水（王安宇 饰）碰到最仗义的女生大吉（王玉雯 饰），二人坠入爱河，他们在逼仄的出租屋内构想美好，在艰苦的日子中苦中作乐、相濡以沫。这段记录，在十八年后被一对零零后的年轻男女发现，成为了这场青春爱情的观影者和吐槽者。两代人的相遇和交织，启动了关于爱情的追忆和反思：到底“值不值”，还能“敢不敢”？','https://pic1.imgdb.cn/item/6810d86c58cb8da5c8d46e66.png','https://pan.baidu.com/s/1tkkjwArdrdqkZslu2W1QMA?pwd=6666 ',1),(8,'盲杀','王辉 / 李恰 / 许东哲 / 戚彩 / 李博','2025-05-01 11:12:02','顾北是一位盲眼乞丐，因路遇屠镇灭门的惨剧，为报答富家千金兰秋瑶的一粥之恩，他开始探寻惨剧背后的真相，却不料遭真凶南烛郎的杀人灭口。兰秋瑶的惨死，点燃了顾北心中沉寂许久的火焰，他再次变回了修罗场上的杀神“夜不收”。凭一身侠肝义胆，为惨死的青石镇百姓和兰家三十口人讨回了公道。','https://pic1.imgdb.cn/item/6810d8dc58cb8da5c8d46ea2.png','https://pan.baidu.com/s/1Zo4SPa7P3y0HjEF-COteYQ?pwd=1024',2),(9,'误杀3','肖央 / 佟丽娅 / 段奕宏 / 刘雅瑟 / 王龙正','2025-04-29 21:54:57','郑炳睿（肖央 饰）的宝贝女儿婷婷众目睽睽之下，遭神秘绑匪绑架，始终陪伴父女左右的李慧萍（佟丽娅 饰）与他一同展开救女行动。但狡诈绑匪轻松躲避警方负责人张景贤（段奕宏 饰）的密集追捕，更将救女心切的郑、李二人玩弄于股掌之间。绝望间，郑炳睿选择走上了一条通往地狱的救女之路，纵使化身“修罗”也不能放过伤害自己女儿的恶徒！殊不知一场更大的阴谋正在悄然展开，所有卷入其中的人都无法逃脱。','https://pic1.imgdb.cn/item/6810d91d58cb8da5c8d46ed2.png','https://pan.baidu.com/s/16Z2TyPxy3TRaK0Y22XRo5w?pwd=6666 ',2),(10,'悬崖之上',' 张译 / 于和伟 / 秦海璐 / 朱亚文 / 刘浩存','2025-04-29 21:54:51','　20世纪30年代，华夏大地成为各方势力角逐厮杀的修罗场。张宪臣（张译 饰）、张兰（刘浩存 饰）、王楚良（朱亚文 饰）和王郁（秦海璐 饰）等四名在苏联接受特训的共产党特工人员，按照组织的指示秘密潜入伪满洲国执行任务。但是由于组织内部出现叛徒，他们的行踪早已被特务科科长高彬（倪大红 饰）获悉。高彬阴狠狡诈，手下鹰犬更是嗜血成性，他旋即为四人组成的乌特拉小组布下了凶险非常的天罗地网。而为了保全四人安全，潜伏在敌人内部的地下党同志也想尽一切办法和对手周旋。','https://pic1.imgdb.cn/item/6810d98c58cb8da5c8d46f08.png','https://pan.baidu.com/s/1-FFhBlpsGs3Bt_Vj3eEi8Q?pwd=vnvf',2),(11,'天堂旅行团',' 彭昱畅 / 杨恩又 / 魏大勋 / 李雪琴 / 吴谨言','2025-04-29 21:57:10','生活失意的宋一鲤（彭昱畅 饰）被人小鬼大的女孩余小聚（杨恩又 饰）“绑架”踏上未知旅程。旅途中他们和形形色色的人一起分享欢笑泪水，彼此温暖治愈，撕开暗夜照亮深渊。人生所有起落和灿烂，都是独一无二的体验。','https://pic1.imgdb.cn/item/6810daab58cb8da5c8d46f9b.png','https://pan.baidu.com/s/1RJK3hdYdohB8XXKjVlVmLA?pwd=6666 ',2),(12,'焚城',' 刘德华 / 白宇 / 莫文蔚 / 谢君豪 / 王菀之','2025-04-29 22:00:24','危险物质突发泄漏！24小时后危及香港全城。 　　如何及时阻止这场末日灾难，专家范伟立（刘德华 饰）与Cecilia（莫文蔚 饰）各执一词。同时，消防队长黎杰峰（白宇 饰）和队友已奉命奔赴未知前线。','https://pic1.imgdb.cn/item/6810db5958cb8da5c8d46ff4.png','https://pan.baidu.com/s/1Z-B18RL5m9jfWVff4hsH3A?pwd=6666 ',2),(13,'哈哈哈哈哈5',' 邓超 / 陈赫 / 高瀚宇 / 范志毅 / 王勉 / 敖瑞鹏 / 任重','2025-04-30 09:59:33','五哈”旅行兄弟团即将再次启程，《哈哈哈哈哈》第五季步履不停探索祖国广阔土地，把快乐继续传递。','https://pic1.imgdb.cn/item/681183fb58cb8da5c8d51d75.png','https://pan.baidu.com/s/1c57VbEKmsyqJzthkcZ6RzQ?pwd=6666 ',3),(14,'唐人街探案1-3 唐探1900',' 王宝强 / 刘昊然 ','2025-05-01 11:25:10','唐人街探案1-3 唐探1900','https://pic1.imgdb.cn/item/6811882b58cb8da5c8d51f77.png','https://pan.baidu.com/s/1GXTKp30ZzOUe_SYJhVO--A?pwd=eszw ',2),(16,'美国队长4',' 罗伯·爱德华兹 / 马尔科姆·斯佩尔曼 / 达兰·穆森 ','2025-05-01 11:35:58','能够展翅高飞的猎鹰山姆·威尔逊（安东尼·麦凯 Anthony Mackie 饰）受史蒂夫·罗杰斯的信任所托，接过盾牌，正式成为美国队长。在与美国总统撒迪厄斯·罗斯（哈里森·福特 Harrison Ford 饰）会面后，山姆发现自己被卷入了一场国际事件。他必须赶在真正的幕后黑手让全世界陷入混乱之前查明真相，揭露这起波及全球的阴谋。','https://vip.123pan.cn/1814266124/ymjew503t0n000d7w32y5curmkl7xj2sDIYPAdizAqevAcxPBIrPAO==.png','https://pan.baidu.com/s/1ky4USUMN6xvN6mfVG7OgOg?pwd=1024',2),(15,'漫威系列电影合集50部 4K REMUX原盘【收藏版】','合集','2025-05-01 11:18:21','漫威系列电影合集50部 4K REMUX原盘【收藏版】','https://vip.123pan.cn/1814266124/yk6baz03t0n000d7w33gzqucw3lmhcllDIYPAdizAqevAcxPBIrPAO==.png','https://pan.baidu.com/s/11n1Th6seHr-26SUPyHcauw?pwd=vnce',2),(17,'射雕英雄传：侠之大者',' 肖战 / 庄达菲 / 梁家辉 / 张文昕 / 巴雅尔图','2025-05-01 11:34:09','恩怨情仇的江湖，权势角力的战乱时代，郭靖（肖战 饰）童年离别家乡，逐渐炼就可改变局面和命运的庞大力量。虽受高人赏识和器重，得传天下绝世武功“九阴真经”和“降龙十八掌”，却惹来各方嫉忌，成为众矢之的。','https://vip.123pan.cn/1814266124/yk6baz03t0l000d7w33fd306feqdrkbpDIYPAdizAqevAcxPBIrPAO==.png','https://pan.baidu.com/s/1CVlKWfo7FY04tKYZkMcGpA?pwd=1024',2),(18,'想飞的女孩',' 刘浩存 / 文淇 / 张宥浩 / 刘奕铁 / 彭静','2025-05-01 11:35:42','　影片讲述了一对表姐妹二十余年的成长与救赎：拼死逃离毒窟的田恬（刘浩存 饰）走投无路，前去寻找已决裂五年的表姐方笛（文淇 饰）。但此时，为了生存和梦想已伤痕累累的方笛并没有做好接纳表妹的准备。随着犯罪分子的步步紧逼，姐妹二人命运的齿轮不得不重新咬合在一起……','https://vip.123pan.cn/1814266124/ymjew503t0l000d7w32x7khkq3pz6pe5DIYPAdizAqevAcxPBIrPAO==.png','https://pan.baidu.com/s/1-bsGiphFXyGm9rl1_114Yw?pwd=1024',2),(19,'域外营救 Exterritorial',' 让娜·古尔索 / 多格雷·斯科特 / 蕾拉·阿波娃','2025-05-01 13:29:41','前特种部队士兵萨拉（让娜·古尔索饰）的小儿子在参观美国驻法兰克福领事馆时失踪得无影无踪。更奇怪的是，似乎没有人记得他曾经来过这栋大楼。萨拉知道德国当局在领事馆内没有管辖权，如果她现在被迫离开，可能就再也见不到儿子了。萨拉深入领事馆的迷宫，拼命寻找她的儿子，却没有意识到周围黑暗阴谋所带来的危险逐渐逼近。','https://vip.123pan.cn/1814266124/ymjew503t0l000d7w32x7khty6pzk39dDIYPAdizAqevAcxPBIrPAO==.png','https://pan.baidu.com/s/1qkMG21DJhZprAAAcwjn98g?pwd=x66b',2),(20,'大侦探·拾光季','何炅 / 张若昀 / 大张伟 / 王鸥 / 杨蓉','2025-05-02 13:20:05','互联网普法教育推理节目。','https://vip.123pan.cn/1814266124/yk6baz03t0m000d7w33g6tmnes61zgysDIYPAdizAqevAcxPBIrPAO==.png','https://pan.baidu.com/s/1F1ZaTh4zNFCTORq1RpuU3A?pwd=1024',3),(21,'开始推理吧 第三季',' 白宇 / 迪丽热巴 / 金靖 / 刘宇宁 / 张凌赫','2025-05-02 13:27:42','　第三季“推市”重启！由白宇、迪丽热巴、金靖、刘宇宁、张凌赫、周柯宇组成的“赫丽摸金宇”推理团再度聚首，开启角色快穿推理好友局！他们将在迷雾中解锁不同身份，破解五大主题奇案，探索 “推市” 背后的终极真相！','https://vip.123pan.cn/1814266124/yk6baz03t0m000d7w33g6tmoec620to7DIYPAdizAqevAcxPBIrPAO==.png','https://pan.baidu.com/s/1HqdkGTIGmUFtJT45qSkP7A?pwd=1024',3),(22,'恋爱兄妹',' 吴尊 / 朱丹 / 宋妍霏 / 蒋敦豪 / 杨亘','2025-05-02 13:32:50','　韩综原版模式引进，爱奇艺打造中国版手足干预恋爱社交治愈系暖综。','https://vip.123pan.cn/1814266124/yk6baz03t0m000d7w33g6tmp9m6217wyDIYPAdizAqevAcxPBIrPAO==.png','https://pan.baidu.com/s/1ywNtYptmUCV-faW37BnXIw?pwd=1024',3),(23,'老有意思旅行社',' 吴克群 / 温岚 / 武艺 / 黄龄 / 吴佩岭','2025-05-02 13:33:42','吴克群作为“老有意思旅行社”的社长，带领一众社员，和老有意思的银发老朋友们，一路的旅行，一路完成心愿。','https://vip.123pan.cn/1814266124/ymjew503t0n000d7w32y5cvnfml9qa41DIYPAdizAqevAcxPBIrPAO==.png','https://pan.baidu.com/s/1HhYSGThGebjoC7vJVopKpA?pwd=1024',3),(24,'妻子的浪漫旅行2025 ','戚薇 / 李承铉 / 韩庚 / 卢靖姗 / 胡静','2025-05-02 13:31:27','《妻子的浪漫旅行2025》是一档创新型家庭关系成长类真人秀，聚焦跨国婚姻中的文化差异与融合。节目以“拥抱差异才是爱的意义”为主题，邀请来自不同国家地区、行业、年龄段的四组夫妻，通过全球旅行展现他们在跨文化背景下的生活、互动和情感。','https://vip.123pan.cn/1814266124/yk6baz03t0n000d7w33gzqw85aloeywjDIYPAdizAqevAcxPBIrPAO==.png','https://pan.baidu.com/s/1Mgndw1-c7BcznnCk89uymQ?pwd=1024',3),(25,'乘风2025',' 叶童 / 邓萃雯 / 陈德容 / 曹颖 / 彭小苒 / 李艺彤','2025-05-02 13:20:46','三十而历，天地她行，《乘风2025》首度走向户外，与她们共同打造“没有天花板”的户外公演！她们脚步奔涌，向未知开疆；乘兴出发，共赴五段她行之路。','https://vip.123pan.cn/1814266124/yk6baz03t0l000d7w33fd31tpvqfnpvtDIYPAdizAqevAcxPBIrPAO==.png','https://pan.baidu.com/s/1sIDci2LeO48E9qQbilL6ZQ?pwd=1024',3),(26,'百分百歌手·对战季','阿达娃 / 蔡淳佳 / 安崎 / 陈思键 / 方炯镔','2025-05-01 17:39:42','　《百分百歌手•对战季》采用舞台对战积分制，将64位歌手分为AB两组，经过多轮不同形式的舞台PK，最终通过累计积分争夺冠亚季军。','https://vip.123pan.cn/1814266124/ymjew503t0l000d7w32x7killwq10bm8DIYPAdizAqevAcxPBIrPAO==.png','https://pan.baidu.com/s/1vnZeJN-YmkaPp4NX9NMjPg?pwd=1024',3),(27,'音你而来2',' 张震岳 / 张碧晨 / 武艺 / 王琳凯 / 欧阳娜娜','2025-05-01 17:43:00','游走大马街头，体验南洋文化，一切都是最美好的音乐旅行。','https://vip.123pan.cn/1814266124/ymjew503t0n000d7w32y5cvoegl9sqkjDIYPAdizAqevAcxPBIrPAO==.png','https://pan.baidu.com/s/1d_TRNqXBE7qw6RSGGvlCXQ?pwd=1024',3),(28,'我叫赵甲第2',' 贺鹏 / 丁笑滢 / 令卓 / 常荻 / 杨祺如 ','2025-05-03 14:58:50','赵甲第本该是人人艳羡的富二代，父亲赵鑫一手打造的金海实业是北方响当当的财富帝国，可赵甲第却拒绝接受赵鑫的金钱，因为那背后饱含着惨遭抛弃的母亲和孤独成长的自己的辛酸苦楚。前传故事中，历经磨难的赵甲第了解到赵鑫也有难言的另一面，金海危机时，独挑大梁的他开始走向与父亲的和解之路，只是世事难测，血缘给予他们羁绊，却也将他们推上了一生竞争的命运。','https://vip.123pan.cn/1814266124/ymjew503t0l000d7w32x7kim4oq11c9hDIYPAdizAqevAcxPBIrPAO==.png','https://pan.baidu.com/s/1Sm6yDZRKVVjTo8Y4lgHj0w?pwd=1024',1),(29,'熊出没·重启未来','熊大/ 熊二/ 光头强','2025-05-01 17:49:54','　熊大、熊二、光头强意外地和来自未来世界的小亮一起穿越到100年后：世界发生巨大灾变，孢子植物全面侵占，人类在末日中艰难求生，整个地球危在旦夕！而这一切的罪魁祸首竟是......光头强？！','https://vip.123pan.cn/1814266124/yk6baz03t0l000d7w33fd31wkjqfqxi1DIYPAdizAqevAcxPBIrPAO==.png','https://pan.baidu.com/s/1Ss10FRVarI3oDPpqKYAfMQ?pwd=1024',2),(30,'完美世界',' 锦鲤 / 李诗萌 / 楚越 / 文靖渊 / 赵爽 / 聂曦映','2025-05-01 20:11:22','完美世界 第五季新篇章 寒界破局篇 10.3起精彩继续，敬请期待！','https://vip.123pan.cn/1814266124/ymjew503t0l000d7w32x7kisk9q1d6siDIYPAdizAqevAcxPBIrPAO==.png','https://pan.baidu.com/s/1ymbbqTVbf-CiChAzBc1Hag?pwd=1024',4),(31,'蛮好的人生',' 孙俪 / 董子健 / 胡杏儿 / 高鑫 / 陈瑶','2025-05-03 14:59:39','　三十九岁的保险从业人员胡曼黎在以为自己即将迎接人生巅峰之时，却同时失去了婚姻和工作。竞争对手暗中作梗，胡曼黎惨遭公司开除，而始作俑者竟是二十八岁的薛晓舟。胡曼黎在与薛晓舟几番交手后，他们逐渐从误解到相互认同，胡曼黎决定不计前嫌和薛晓舟联手合作，从头再来。薛晓舟成长为保险业界不容小觑的金牌销冠，胡曼黎也决定回归自己的事业主场。','https://vip.123pan.cn/1814266124/yk6baz03t0n000d7w33gzqwl8glotd9bDIYPAdizAqevAcxPBIrPAO==.png','https://pan.baidu.com/s/1scr7xGbyw3zJ9zV48DeqVw?pwd=1024 ',1),(32,'无尽的尽头',' 任素汐 / 高伟光 / 刘琳 / 刘家祎 / 张小婉','2025-05-03 18:34:35','聚焦未成年人司法保护，讲述了未成年人检察小组初创，检察官林之桃与助理检察员白恩宇，为了孩子们，携手对抗人性之恶的故事。','https://vip.123pan.cn/1814266124/ymjew503t0m000d7w32xp3zttu5nsjs4DIYPAdizAqevAcxPBIrPAO==.png','https://pan.baidu.com/s/1-ZK2sD2k44YdzyEod8zjMA?pwd=1024',1),(33,'落花时节又逢君',' 廖宇嘉 / 王达 / 杨旎 / 朱雍颖 / 杜衡','2025-05-03 14:59:21','根据蜀客的同名小说改编，主要是讲述千年的茶花小妖与掌管中天的中天王之间的千年纠葛爱情的故事。','https://vip.123pan.cn/1814266124/yk6baz03t0l000d7w33fd326yuqg2jdmDIYPAdizAqevAcxPBIrPAO==.png','https://pan.baidu.com/s/1pi2StgDQPPXhCfbQlkLTLw?pwd=1024 ',1),(34,'淮水竹亭',' 缪文静 / 丁娅 / 简暗 / 未再 / 徐弘','2025-05-03 18:34:39','　故事讲述了神火山庄大小姐东方淮竹(刘诗诗 饰)去南垂平妖，偶遇行侠仗义的面具团老大王权弘业(张云龙 饰)，两人深入南垂腹地，大战南垂妖皇。','https://vip.123pan.cn/1814266124/yk6baz03t0m000d7w33g6tn37w62h0scDIYPAdizAqevAcxPBIrPAO==.png','https://pan.baidu.com/s/1c4uXx18hw2xpqV5gIR9qdw?pwd=1024',1),(35,'狮城山海',' 巍子 / 杨旭文 / 王梓薇 / 洪浚嘉 / 岳丽娜','2025-05-01 22:42:07','上世纪40年代末，沿着马六甲河岸的一带，聚集了许多来此谋生的华人族群，他们在岁月磨难中，同乡互助，顽强拼搏，在立稳脚跟后，一个富有传奇色彩的堂口帮会“山海帮”渐渐成为当地华人的发展中心。','https://vip.123pan.cn/1814266124/ymjew503t0n000d7w32y5cvulwla5oddDIYPAdizAqevAcxPBIrPAO==.png','https://pan.baidu.com/s/1av2fQqhahHNXd94ycnQOOg?pwd=1024',1),(36,'盒子里的猫 第二季',' 陈赫 / 黄子弘凡 / 林更新 / 王迅 / 徐志胜','2025-05-03 15:00:07','第二季盒子世界多维升级，将围绕“从盒子里看世界”的概念，解锁人生无限可能。节目中，明星玩家被输送到10个充满不确定性的平行世界，通过游戏闯关的方式观照当下社会话题，在不确定性中找到与自我和解的答案。','https://vip.123pan.cn/1814266124/ymjew503t0l000d7w32x7kklosq4gc92DIYPAdizAqevAcxPBIrPAO==.png','https://pan.baidu.com/s/1CJl36SAJoYtal8q4GxvnJg?pwd=1024 ',3),(37,'这是我的西游',' 马嘉祺 / 丁程鑫 / 宋亚轩 / 刘耀文 / 张真源','2025-05-03 14:59:55','《这是我的西游》是由优酷精心策划并倾力打造的国民奇幻IP少年成长真人秀综艺，预计将于2025年Q2播出。节目通过“游戏”+”户外”的破圈公式，以经典西游IP为蓝本，历经十世副本，挑战81个脑洞大开的闯关游戏，触发层层反转的爆笑剧情。以魔幻现实主义故事直击现代社会热点，在一路成长历练中悟得“悟空精神”！','https://vip.123pan.cn/1814266124/yk6baz03t0n000d7w33gzqzphsls2j35DIYPAdizAqevAcxPBIrPAO==.png','https://pan.baidu.com/s/1upbex5Bn_kGCoOfcENysRA?pwd=1024 ',3),(38,'第六个嫌疑人 ','那志东 / 石兆琪 / 魏璐 / 要武 / 陈韵锦','2025-05-02 13:44:52','该片讲述了刑警队队长董国强和方言等不畏艰辛、排除重重阻碍，终于破获了诡异的“坟地藏尸案”，新入警的刑警方言也在案件的侦破中得到了成长，完成了以父亲方志勇为代表的老一辈刑警夙愿的故事。','https://vip.123pan.cn/1814266124/yk6baz03t0l000d7w33fd35a1tqjc51hDIYPAdizAqevAcxPBIrPAO==.png','https://pan.baidu.com/s/1BO4FYjVBxhamoejAFAPOxg?pwd=1024 ',2),(39,'沧元图',' 张磊 / 段艺璇 / 马斑马 Banma Ma / 姜广涛','2025-05-02 13:49:12','沧元界妖邪作乱，人族饱受摧残，主角孟川自小立下为母复仇的誓言，以镜湖道院为起点，凭借坚毅无畏的心志与利落果决的刀法身手，惩处奸恶，溃灭妖族，登顶四大道院，名满东宁府，拜上元初山，成就一代神魔。','https://vip.123pan.cn/1814266124/ymjew503t0n000d7w32y5cxe9vld98fgDIYPAdizAqevAcxPBIrPAO==.png','https://pan.baidu.com/s/1-w2_cG3Rk-2kPg1HXveqEA?pwd=1024',4),(40,'天命大主宰',' 许子尧 / 张英 / 李晓宝 / 乔涛涛','2025-05-02 13:51:22','大贺神州，自古正邪对立，正道诸多宗门联合，对抗肆意妄为的魔道十二宗。但数百年来，随着魔潮突然爆发，魔门势力不断壮大，压迫得正道宗门步步后退，可谓是危急存亡之秋。修为普通的李万年，是正道锦衣宗的低阶神通者，人生理想只是在锦衣宗里躺平，安心领一份薪水。但是，一次应付交差的任务中，他却在生死危机之际，突然发现，自己拥有原地复活的不死能力。更重要的是，他每次复活之后，还能根据被斩杀时的综合表现，获得相应的点数奖励，从而提升修为。换句话来说，李万年想要提升修为，不仅要多死几次，而且还要死得漂亮、死得其所、死得壮烈、死得有价值、死得让人热血沸腾受到感召……','https://vip.123pan.cn/1814266124/ymjew503t0n000d7w32y5cxeqylda4usDIYPAdizAqevAcxPBIrPAO==.png','https://pan.baidu.com/s/1blPOl0uaooqG3ZNEKjkR6A?pwd=1024 ',4),(41,'超能立方',' 杨昕燃 / 叶知秋 / 瞳音 / 王铕瑞','2025-05-02 13:53:35','　平凡少年王小修在一次意外中，获得了来自高纬度宇宙文明的空间系统“超能立方”，从而拥有了超凡能力。因被自己恋慕许久的校花沈瑶表白，王小修惹恼了同为沈瑶追求者的不良青年孙俊，王小修靠机智和超凡能力化解了危机，但也引来了更多的祸患。','https://vip.123pan.cn/1814266124/ymjew503t0l000d7w32x7kkn9oq4jfu6DIYPAdizAqevAcxPBIrPAO==.png','https://pan.baidu.com/s/1orEgrQEmQZiP24ko_oM2MA?pwd=1024',4),(42,'流水迢迢',' 任嘉伦 / 李兰迪 / 徐正溪 / 高寒 / 张雅钦','2025-05-02 14:16:14','月落城少城主萧无瑕，忍辱负重潜伏梁国多年，化名为卫昭，背负佞臣骂名。卫昭为查清当年家族真相，试图掳走齐王案的唯一活口，但自己精心布置的计划却被突然出现的少女江慈所破坏。裴琰趁机将重伤的江慈养入府中，以求找到幕后“破坏者”。','https://vip.123pan.cn/1814266124/ymjew503t0l000d7w32x7kkobhq4le2qDIYPAdizAqevAcxPBIrPAO==.png','https://pan.baidu.com/s/1x2OpP3X_uhGhOssNcvrp1Q?pwd=1024',1),(43,'藏珠',' 赵夕汐 / 张翅 / 张洪鸣 / 赵安第 / 胡宾格 / 林亚冬','2025-05-02 14:57:09','将军府庶女李楚楚自幼被主母狠狠压制了十几年，遭逢命运剧变时，意外得知亲生母亲的死亡背后另有推手，决定为母报仇，并在此过程中和嫡兄李轸陷入爱恨痴缠，二人在你来我往的深情克制中探寻真相与正义……','https://vip.123pan.cn/1814266124/yk6baz03t0l000d7w33fd35hsoqjm2wgDIYPAdizAqevAcxPBIrPAO==.png','https://pan.baidu.com/s/1ElpH6cJl5ettc0GIwog-Gw?pwd=1024 ',1),(44,'斗罗大陆 绝世唐门','梁达伟','2025-05-03 14:44:59','这里没有魔法，没有斗气，没有武术，却有武魂。唐门创立万年之后的斗罗大陆上，唐门式微。一代天骄横空出世，新一代史莱克七怪能否重振唐门，谱写一曲绝世唐门之歌?百万年魂兽，手握日月摘星辰的死灵圣法神，导致唐门衰落的全新魂导器体系。一切的神奇都将一一展现。唐门暗器能否重振雄风，唐门能否重现辉煌~','https://vip.123pan.cn/1814266124/yk6baz03t0n000d7w33gzr9cnwm2p1s4DIYPAdizAqevAcxPBIrPAO==.png','https://pan.baidu.com/s/18fTA0AkCLuywMQ6n_ImrHQ?pwd=1024',4),(45,'镇魂街 第四季',' 郭盛 / 黎筱濛 / 图特哈蒙 / 锦鲤','2025-05-03 14:45:59','曹焱兵一行因芦花古楼的覆灭被皇甫龙斗领导的天罡龙棋将栽赃嫁祸，全员受到灵域的通缉，在经过“天武街”和“风雷街”时，他们分别遭遇了王国组织的第三骑士红莲与第十骑士凯米拉。其后，曹焱兵为探寻母亲下落，故意被缉拿至由群英殿镇守的死牢“千机黑刹”。而其伙伴们为救曹焱兵，在多方驰援下，各方势力齐聚群英殿，展开了一场精彩绝伦的群英荟萃之战。','https://vip.123pan.cn/1814266124/ymjew503t0n000d7w32y5d2k0wlns3ckDIYPAdizAqevAcxPBIrPAO==.png','https://pan.baidu.com/s/1upOQMEJDoj76E_r-yNb4BA?pwd=1024 ',4),(46,'奔跑吧 第九季',' 李晨 / 郑恺 / 沙溢 / 白鹿 / 周深 / 范丞丞 / 宋雨琦 ','2025-05-03 14:51:31','《奔跑吧》新一季将于3月底开录，','https://vip.123pan.cn/1814266124/ymjew503t0l000d7w32x7kt3rxqfipeoDIYPAdizAqevAcxPBIrPAO==.png','https://pan.baidu.com/s/10ox-6Vn3cxI8PcooS_BrFQ?pwd=1024 ',3),(47,'凡人修仙传',' 钱文青 / 王敏纳 / 刘思岑 ','2025-05-03 14:54:04','　看机智的凡人小子韩立如何稳健发展、步步为营，战魔道、夺至宝、驰骋星海、快意恩仇，成为纵横三界的强者。他日仙界重相逢，一声道友尽沧桑。','https://vip.123pan.cn/1814266124/yk6baz03t0m000d7w33g6u1gpz6h11d0DIYPAdizAqevAcxPBIrPAO==.png','https://pan.baidu.com/s/1vMMsFxjE61RzZNB5y_u3eg?pwd=1024',4),(48,'哈哈哈哈哈 第五季',' 邓超 / 陈赫 / 高瀚宇 / 范志毅 / 王勉 ','2025-05-03 14:56:38','　“五哈”旅行兄弟团即将再次启程，《哈哈哈哈哈》第五季步履不停探索祖国广阔土地，把快乐继续传递。','https://vip.123pan.cn/1814266124/ymjew503t0m000d7w32xp46zv861xdiqDIYPAdizAqevAcxPBIrPAO==.png','https://pan.baidu.com/s/16bB1UUigXta7tbGoTs94sw?pwd=1024 ',3),(49,'命悬一枪',' 张晋 / 程怡 / 韩彦博 / 国义骞 / 宁桓宇','2025-05-03 15:08:09','　乱世之中，土匪横行，一心搞钱的痞匪彭一男（张晋饰）与兄弟雷五（国义骞 饰）、麻明（宁桓宇 饰）结伴走江湖、讨生计。陌生女子庄月（程怡饰）见识过他们的拳脚和计谋后，以一根金条为酬，托三人上山劫亲，反向抢人！谁知在这穷凶极恶的匪窝中，彭一男苦寻多年未果的灭门仇人，竟也意外显露踪迹……新仇旧恨、家仇民愤一起算，真狠人彭一男闯匪窝，讨血债，爽除恶，杀到底！','https://vip.123pan.cn/1814266124/yk6baz03t0n000d7w33gzr9x2fm3ffyoDIYPAdizAqevAcxPBIrPAO==.png','【超级会员V1】通过百度网盘分享的文件：命丨悬一枪 链接：https://pan.baidu.com/s/1Lf85rnjIzL7uSFZcmhtLcg?pwd=1024  提取码：1024',2),(50,'天赐的声音 第六季',' 张靓颖 / 谭维维 / 张碧晨 / 吉克隽逸 / 姚晓棠','2025-05-03 18:32:13','　《天赐的声音第六季》是浙江卫视推出的音乐励志节目，由陶喆担任天赐召集人，黄子弘凡、吉克隽逸、刘宇宁、谭维维、王赫野、王以太、王源、杨坤、姚晓棠、张碧晨、张靓颖（按姓名首字母排序）组成首轮音乐合伙人','https://vip.123pan.cn/1814266124/yk6baz03t0m000d7w33g6u2jco6i3g45DIYPAdizAqevAcxPBIrPAO==.png','https://pan.baidu.com/s/1tSFpanBO5eQ9DYFRINQfyw?pwd=1024 ',3),(51,'斗破苍穹 年番','不一 / 陈奕雯 / 冯骏骅 / 醋醋 / 夏磊','2025-05-03 19:59:57','斗破苍穹 中州风云志','https://vip.123pan.cn/1814266124/ymjew503t0n000d7w32y5d3f1nlpkpt7DIYPAdizAqevAcxPBIrPAO==.png','https://pan.baidu.com/s/1TFeXpnMtk0LjCCTBW_4nTg?pwd=1024',4),(52,'你好星期六','何炅 / 檀健次 / 李雪琴 / 秦霄贤 / 王鹤棣','2025-05-04 07:54:29','　节目重点围绕艺人艺能的全面深度挖掘、精品表演秀的创意呈现、最具热点的社会性话题输出等方面进行设计，开创剧综联动新玩法。何炅担任主持人，檀健次、李雪琴、秦霄贤、王鹤棣、丁程鑫、杨迪、吴泽林等担任阶段性常驻嘉宾，每期会邀请几位飞行嘉宾参与录制，包括各行各业的代表以及不同领域的艺术团体。节目内容由访谈、互动、秀等环节构成，是一个集观众表达、主流表达、娱乐表达三位一体的国民综艺。','https://vip.123pan.cn/1814266124/yk6baz03t0l000d7w33fd3igphqx8s9cDIYPAdizAqevAcxPBIrPAO==.png','https://pan.baidu.com/s/1EwwhFinMXWslKFT9z-uqnA?pwd=1024 ',3),(53,'乐在旅途 第三季','陆虎、胡夏、希林娜依·高、白举纲','2025-05-04 07:57:04','四人组成的寻音乐队踏青出发，在春日的脉络里重走千年音律，绘制全新一季音乐山河图.','https://vip.123pan.cn/1814266124/yk6baz03t0m000d7w33g6u42qx6jn2wxDIYPAdizAqevAcxPBIrPAO==.png','https://pan.baidu.com/s/1m9zPLaWarqg7tWPBl9x7Bw?pwd=1024',3),(54,'名侦探柯南',' 高山南 / 山崎和佳奈 / 神谷明 / 小山力也','2025-05-04 08:07:43','　工藤新一是全国著名的高中生侦探，在一次追查黑衣人犯罪团伙时不幸被团伙成员发现，击晕后喂了神奇的药水，工藤新一变回了小孩！新一找到了经常帮助他的阿笠博士，博士为他度身打造不少间谍武器。为了防止犯罪团伙对他进行报复，新一决定隐姓埋名，暗中追查他们，希望能得到解药。','https://vip.123pan.cn/1814266124/ymjew503t0n000d7w32y5d3zqxlqr2h3DIYPAdizAqevAcxPBIrPAO==.png','https://pan.baidu.com/s/1ZQyjvpVrAx59fZ8AlWP_3g?pwd=1024',4),(55,'无限超越班 第三季',' 尔冬升 / 郝蕾 / 李诚儒 / 刘涛 / 吴镇宇','2025-05-04 08:09:52','节目第三季将延续前两季的经典模式，由业内老戏骨监制团带领两地中青年演员共同聚焦演员职场生态，回归演员初心，以经典影视作品为主要演绎题材，展开能力与素养的双重考验，直面市场，近距离接触顶级资源，最终诞生年度无限之星。','https://vip.123pan.cn/1814266124/yk6baz03t0n000d7w33gzrbxzzm60slqDIYPAdizAqevAcxPBIrPAO==.png','https://pan.baidu.com/s/1TXfneHRC_2NLs5IxYyyjuQ?pwd=1024 ',3),(56,'演员请就位 第三季',' 陈凯歌 / 章子怡 / 伊莎贝尔·于佩尔 / 吴镇宇','2025-05-04 08:11:47','以影视行业演员的生存现状为策划依托，还原行业选角、定妆试戏、争取角色、跑组排练、片场拍摄等一系列真实过程，围绕新一季节目核心理念「帮助演员找到属于自己的赛道」分成4个阶段。','https://vip.123pan.cn/1814266124/ymjew503t0m000d7w32xp489vd64fpnmDIYPAdizAqevAcxPBIrPAO==.png','https://pan.baidu.com/s/1-YgfMSZyMbEJ9EyKSrPDVw?pwd=1024 ',3),(57,'快乐的大人 第二季','沈月 / 王敬轩 / 吴宇恒 / 武艺 / 范世錡','2025-05-04 14:40:36','　沈月、王敬轩、吴宇恒等人再度集结，前往三个快乐目的地，带观众领略不同的风景，展现熟人局之间相处的真实模样，延续第一季自制的松弛感和追求快乐的初心，希望每一位观众都可以做快乐的大人。','https://vip.123pan.cn/1814266124/yk6baz03t0n000d7w33gzrfy6nmb7zwfDIYPAdizAqevAcxPBIrPAO==.png','https://pan.baidu.com/s/1ZkridZHhyZj_TmKetBv7OA?pwd=1024 ',3),(58,'周游记 第三季','周杰伦','2025-05-04 14:43:45','节目以一首周杰伦经典歌曲，一座城，一个故事，呈现周杰伦与众不同的“魔幻之旅”。杰伦与他的好朋友们，一起随着熟悉的旋律，去探索，去分享，去追逐。','https://vip.123pan.cn/1814266124/yk6baz03t0l000d7w33fd3ne9ir2ijymDIYPAdizAqevAcxPBIrPAO==.png','https://pan.baidu.com/s/16JA7tnP9gMJOiBLDnuWndg?pwd=1024 ',3),(59,'牧神记',' 张若瑜 / 李欣 / 程玉珠 / 杜晴晴 / 虞晓旭','2025-05-04 15:08:38','　秦牧天生凡体，历经考验成为天魔教教主，被延康国封为第一任太学博士。延康国叛乱之战中秦牧引来魔神，掀起浩荡风云，后随武可汗入楼兰黄金宫，一个人打遍圣宫无敌手。他返回延康,助国师平叛、造射日神炮，后得人皇传承成为新一代人皇。机缘巧合下秦牧得知自己的身世,借助道门小玉京等人帮助，开启道法神通改革的大世。','https://vip.123pan.cn/1814266124/ymjew503t0n000d7w32y5d6u0qlwig6dDIYPAdizAqevAcxPBIrPAO==.png','https://pan.baidu.com/s/1CwjV13EcDxBMgYmVbQaHcA?pwd=1024',4),(60,'长歌行',' 常蓉珊 / 瞳音 / 马正阳 / 锦鲤 / 赵铭洲','2025-05-04 15:11:48','官方版本一：家破人亡的落魄公主李长歌踏上复仇之路。 　　官方版本二：秦王发动宫变将太子一党诛杀，只有太子之女——公主李长歌一人逃出生天。家破人亡的李长歌发誓要血债血偿，自此踏上了充满坎坷的复仇之路。','https://vip.123pan.cn/1814266124/ymjew503t0m000d7w32xp4b4zr6a8wm4DIYPAdizAqevAcxPBIrPAO==.png','https://pan.baidu.com/s/11IlEmpWm_CY0dMVkYkoJTw?pwd=1024 ',4);
/*!40000 ALTER TABLE `data` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `users`
--

DROP TABLE IF EXISTS `users`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `users` (
  `user_id` int(11) NOT NULL AUTO_INCREMENT,
  `username` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `password` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `registration_time` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `email` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `avatar` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `is_admin` tinyint(1) DEFAULT '0',
  PRIMARY KEY (`user_id`),
  UNIQUE KEY `username` (`username`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `users`
--

LOCK TABLES `users` WRITE;
/*!40000 ALTER TABLE `users` DISABLE KEYS */;
/*!40000 ALTER TABLE `users` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Dumping events for database 'share'
--

--
-- Dumping routines for database 'share'
--
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2025-05-05  2:30:02
